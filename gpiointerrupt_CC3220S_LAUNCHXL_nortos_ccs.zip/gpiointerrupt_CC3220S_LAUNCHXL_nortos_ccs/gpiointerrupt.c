/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Initialize button variables */
int leftButton = 0;                     // Left button for decrement
int rightButton = 0;                    // Right button for increment

/*
 *  ======== gpioButtonFxn0 ========
 *  Left button callback function (interrupt triggered).
 */
void gpioButtonFxn0(uint_least8_t index)
{
    leftButton = 1; // Set left button flag
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Right button callback function (interrupt triggered).
 */
void gpioButtonFxn1(uint_least8_t index)
{
    rightButton = 1; // Set right button flag
}

/*
 *  ======== UART code begin ========
 */
#define DISPLAY(x) UART_write(uart, &output, x);

// UART Global Variables
char output[64];
int bytesToSend;

// Driver Handles - Global variables
UART_Handle uart;

/*
 *  ======== initUART ========
 *  Initialize and configure the UART driver.
 */
void initUART(void)
{
    UART_Params uartParams;
    UART_init();  // Initialize the UART driver

    // Configure the UART parameters
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    uart = UART_open(CONFIG_UART_0, &uartParams); // Open UART with configured settings
    if (uart == NULL)
    {
        // Handle UART_open() failure
        while (1);
    }
}

/*
 *  ======== I2C code begin ========
 */
// I2C Global Variables
static const struct
{
    uint8_t address;
    uint8_t resultReg;
    char *id;
}

sensors[3] =
{
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;
I2C_Handle i2c;

/*
 *  ======== initI2C ========
 *  Initialize and configure the I2C driver.
 */
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;
    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "));

    I2C_init();  // Initialize the I2C driver

    // Configure the I2C parameters
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    i2c = I2C_open(CONFIG_I2C_0, &i2cParams); // Open I2C with configured settings
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r")); // Handle I2C_open failure
        while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"));

    // Scan through possible sensor addresses to determine which sensor is present
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    found = false;

    for (i = 0; i < 3; ++i)
    {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id));

        if (I2C_transfer(i2c, &i2cTransaction)) // Check if the sensor is found
        {
            DISPLAY(snprintf(output, 64, "Found\n\r"));
            found = true;
            break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"));
    }

    // Handle sensor detection result
    if (found)
    {
        DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.slaveAddress));
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"));
    }
}

/*
 *  ======== readTemp ========
 *  Read temperature from the sensor and return in Fahrenheit.
 */
int16_t readTemp(void)
{
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;

    if (I2C_transfer(i2c, &i2cTransaction)) // Perform I2C read transaction
    {
        // Extract temperature data from the sensor
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125; // Convert to Celsius

        if (rxBuffer[0] & 0x80) // Check for 2's complement negative value
        {
            temperature |= 0xF000;
        }

        temperature = (temperature * 1.8) + 32; // Convert to Fahrenheit
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r", i2cTransaction.status));
        DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"));
    }

    return temperature; // Return the temperature in Fahrenheit
}

/*
 *  ======== Timer code begin ========
 */
// Timer Global Variables
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;

/*
 *  ======== timerCallback ========
 *  Timer callback function to set TimerFlag.
 */
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1; // Set flag when timer period completes
}

/*
 *  ======== initTimer ========
 *  Initialize and configure the timer.
 */
void initTimer(void)
{
    Timer_Params params;
    Timer_init();  // Initialize the Timer driver

    Timer_Params_init(&params); // Configure Timer parameters
    params.period = 1000000;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.periodUnits = Timer_PERIOD_US;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params); // Open timer with configured settings
    if (timer0 == NULL)
    {
        while (1); // Handle Timer_open failure
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) // Start the timer
    {
        while (1); // Handle Timer_start failure
    }
}

/*
 *  ======== mainThread ========
 *  Main application thread to manage button inputs, temperature sensor, and UART display.
 */
void *mainThread(void *arg0)
{
    // Initialize GPIO driver
    GPIO_init();

    // Configure red LED and button pins
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    // Turn on the red LED
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    // Install button callback for BUTTON0
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0); // Enable interrupts for BUTTON0

    // Configure BUTTON1 if available
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1)
    {
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1); // Enable interrupts for BUTTON1
    }

    // Initialize drivers and peripherals
    initUART();
    initI2C();
    initTimer();

    // Initialize timing variables and constants
    unsigned long buttonCheckTime = 0;
    unsigned long tempCheckTime = 0;
    unsigned long displayCheckTime = 0;
    const unsigned long buttonCheckPeriod = 200;
    const unsigned long tempCheckPeriod = 500;
    const unsigned long displayCheckPeriod = 1000;
    const unsigned long timerPeriod = 100;

    // Initialize thermostat and system variables
    int setpoint = 78;
    int heat = 0;
    int seconds = 0;
    int temperature = 0;

    /*
     *  ======== Main while loop ========
     *  Continuously check button inputs, update temperature and LED status, and output to UART.
     */
    while (1)
    {
        // Read the current temperature from the sensor
        readTemp();

        // Check for button presses every 200ms
        if (buttonCheckTime >= buttonCheckPeriod)
        {
            if (rightButton == 1)
            {
                setpoint += 1;  // Increment setpoint if right button is pressed
                rightButton = 0; // Reset the right button flag
            }
            if (leftButton == 1)
            {
                setpoint -= 1;  // Decrement setpoint if left button is pressed
                leftButton = 0;  // Reset the left button flag
            }
        }

        // Check temperature and update LED/heat every 500ms
        if (tempCheckTime >= tempCheckPeriod)
        {
            temperature = readTemp(); // Read the current temperature
            if (temperature < setpoint)
            {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON); // Turn on LED if temperature is below setpoint
                heat = 1; // Turn on heat
            }
            else
            {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF); // Turn off LED if temperature is above setpoint
                heat = 0; // Turn off heat
            }
        }

        // Output temperature data to UART every 1000ms
        if (displayCheckTime >= displayCheckPeriod)
        {
            DISPLAY(snprintf(output, 64, "<%02dF,%02dF,%d,%04d>\n\r", temperature, setpoint, heat, seconds));
            ++seconds; // Increment the seconds counter
        }

        // Wait for the next timer period to elapse
        while (!TimerFlag) {}
        TimerFlag = 0; // Reset TimerFlag for the next period

        // Update timing variables
        buttonCheckTime += timerPeriod;
        tempCheckTime += timerPeriod;
        displayCheckTime += timerPeriod;
    }
}
